package Problem3;

public interface Movement extends Flight{

    void walk();
    void jump();


}
