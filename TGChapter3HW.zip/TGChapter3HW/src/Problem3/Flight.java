package Problem3;

public interface Flight {
    void fly();
}
